u'[Machine-generated]\nStorage helpers read binary numeric files and write sorted report lines. Both operate on supplied paths; errors propagate. Python 2 byte formatting and mapping iteration are migration hazards.\n\nObserved return types: \nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'


def read_numbers(path):
    u'[Machine-generated]\nRead a file in binary mode, skip blank stripped lines, and parse the remaining lines as integers. Invalid numeric bytes propagate parsing errors.\n\nObserved return types: list\nObserved exceptions: exceptions.ValueError\nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    with open(path, 'rb') as stream:
        return [int(line.strip()) for line in stream if line.strip()]


def write_report(path, report):
    u'[Machine-generated]\nOpen a report file in binary write mode and serialize sorted mapping entries as key=value lines using iteritems. Opening truncates an existing file before iteration; formatting can expose Python 2 Unicode encoding errors.\n\nObserved return types: NoneType\nObserved exceptions: exceptions.UnicodeDecodeError, exceptions.UnicodeEncodeError\nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    with open(path, 'wb') as stream:
        for key, value in sorted(report.items()):
            stream.write('%s=%s\n' % (key, value))
