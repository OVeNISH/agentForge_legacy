u'[Machine-generated]\nA stateful Scoreboard and comparison helper implement score accumulation and ranking. ranked uses iteritems and a cmp sort argument. The approximate call graph may not resolve the callback edge passed to sort.\n\nObserved return types: \nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'


def compare_scores(left, right):
    u'[Machine-generated]\nCompare score pairs for descending numeric score, then compare lowercased names for ties using cmp. Equal scores and case-insensitive equal names compare equal.\n\nObserved return types: int\nObserved exceptions: exceptions.IndexError\nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    score_order = cmp(right[1], left[1])
    if score_order:
        return score_order
    return cmp(left[0].lower(), right[0].lower())


class Scoreboard(object):
    u'[Machine-generated]\nHold a mutable scores dictionary, accumulate points through add, and expose sorted score rows through ranked. Ranking uses the module comparison helper.\n\nObserved return types: \nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    def __init__(self):
        u'[Machine-generated]\nInitialize an empty scores dictionary on the instance. Construction returns None from initialization; the harness also records instance state.\n\nObserved return types: NoneType\nObserved exceptions: exceptions.TypeError\nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
        self.scores = {}

    def add(self, name, points):
        u'[Machine-generated]\nAdd points to the named score, starting from zero when the name is absent. This mutates the scores dictionary and returns None.\n\nObserved return types: NoneType\nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
        self.scores[name] = self.scores.get(name, 0) + points

    def ranked(self):
        u'[Machine-generated]\nCopy the scores mapping entries into a list and sort them using compare_scores as the comparison function. The original mapping remains in place.\n\nObserved return types: list\nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
        rows = list(self.scores.iteritems())
        rows.sort(cmp=compare_scores)
        return rows


if __name__ == '__main__':
    board = Scoreboard()
    print 'empty:', repr(board.ranked())
    board.add('Lin', 4)
    board.add('ada', 7)
    board.add('Bob', 7)
    board.add('Lin', -1)
    print 'ranked:', repr(board.ranked())
    print 'equal:', compare_scores(('Ada', 7), ('Ada', 7))
