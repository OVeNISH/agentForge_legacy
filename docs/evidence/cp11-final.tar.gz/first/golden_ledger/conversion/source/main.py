u'[Machine-generated]\nA small ledger module with bill division, mapping accumulation and integer parsing. Its main block prints examples. Integer division and legacy exception syntax require migration care.\n\nObserved return types: \nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
from __future__ import print_function


from _legacy_compat import legacy_divide


def split_bill(amount, people):
    u'[Machine-generated]\nDivide the amount among people using Python 2 division. Integer inputs round toward negative infinity; zero divisors raise an error.\n\nObserved return types: int\nObserved exceptions: exceptions.TypeError, exceptions.ZeroDivisionError\nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    return legacy_divide(amount, people)


def summarize(balances):
    u'[Machine-generated]\nAccumulate amounts from the balances mapping using iteritems. An empty mapping leaves the total at zero.\n\nObserved return types: int\nObserved exceptions: exceptions.TypeError\nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    total = 0
    for name, amount in list(balances.items()):
        total += amount
    return total


def parse_amount(text):
    u'[Machine-generated]\nParse an integer and turn ValueError into an invalid-prefix message. Other exceptions propagate, including invalid input types.\n\nObserved return types: int, str\nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    try:
        return int(text)
    except ValueError as error:
        return b'invalid: ' + str(error).encode('ascii')


if __name__ == '__main__':
    print('split:', split_bill(7, 2), split_bill(-7, 2))
    print('total:', summarize({'Ada': 7, 'Lin': -2}))
    print('empty:', summarize({}))
    print('parsed:', parse_amount('12'))
    print('bad:', parse_amount('bad'))
