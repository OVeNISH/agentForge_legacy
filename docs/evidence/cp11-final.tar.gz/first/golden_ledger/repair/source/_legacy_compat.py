"""[Machine-generated] Compatibility for built-in numeric division."""


def legacy_divide(left, right):
    """[Machine-generated] Floor integer quotients; divide other numbers normally."""
    # shortcut: custom Python 2 __div__ protocols are unsupported; review user-defined numeric types.
    if isinstance(left, int) and isinstance(right, int):
        return left // right
    return left / right


def legacy_int_error(error, value):
    """[Machine-generated] Preserve byte-literal diagnostic rendering returned by the legacy API."""
    message = str(error)
    prefix = 'invalid literal for int() with base 10: '
    if isinstance(value, bytes) and message.startswith(prefix + 'b'):
        message = prefix + message[len(prefix) + 1:]
    return message.encode('ascii')
