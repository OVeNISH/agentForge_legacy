[Machine-generated]
The ranking project has one module. Scoreboard owns mutable state; compare_scores defines score/name ordering used by ranked. Preserving accumulated state, tie behavior and comparison sorting is necessary for migration.

Observed return types: 
Observed exceptions: 
Limitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.
