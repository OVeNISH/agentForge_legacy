"""[Machine-generated] Compatibility for built-in numeric division."""


def legacy_divide(left, right):
    """[Machine-generated] Floor integer quotients; divide other numbers normally."""
    # shortcut: custom Python 2 __div__ protocols are unsupported; review user-defined numeric types.
    if isinstance(left, int) and isinstance(right, int):
        return left // right
    return left / right


def legacy_open(path, mode):
    """[Machine-generated] Reject descriptors as Python 2's path-based open did."""
    if not isinstance(path, (str, bytes)):
        raise TypeError('coercing to Unicode: need string or buffer, %s found' % type(path).__name__)
    return open(path, mode)
