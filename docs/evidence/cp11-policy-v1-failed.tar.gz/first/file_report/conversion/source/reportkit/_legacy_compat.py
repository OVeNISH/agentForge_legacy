"""[Machine-generated] Compatibility for built-in numeric division."""


def legacy_divide(left, right):
    """[Machine-generated] Floor integer quotients; divide other numbers normally."""
    # shortcut: custom Python 2 __div__ protocols are unsupported; review user-defined numeric types.
    if isinstance(left, int) and isinstance(right, int):
        return left // right
    return left / right
