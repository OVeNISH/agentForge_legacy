u'[Machine-generated]\nA pure summary helper computes count and an integer-rounded mean, with an explicit empty-input result. No project-local dependencies are imported.\n\nObserved return types: \nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'


from ._legacy_compat import legacy_divide


def summarize(numbers):
    u'[Machine-generated]\nReturn count and mean for numbers. Empty input produces count zero and a None mean; nonempty integer input uses Python 2 integer division. Unsupported element types retain their errors.\n\nObserved return types: dict\nObserved exceptions: exceptions.TypeError\nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    if not numbers:
        return {b'count': 0, b'mean': None}
    return {b'count': len(numbers), b'mean': legacy_divide(sum(numbers), len(numbers))}
