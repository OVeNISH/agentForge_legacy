u'[Machine-generated]\nThe demonstration entry module imports build_report from reportkit and prints its result with sample file paths when run as main. It retains Python 2 print syntax.\n\nObserved return types: \nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
from __future__ import print_function

from reportkit import build_report


if __name__ == '__main__':
    print(repr(build_report('sample.txt', 'report.txt', seed=7)))
