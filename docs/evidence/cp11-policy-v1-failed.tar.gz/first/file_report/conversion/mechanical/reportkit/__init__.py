u'[Machine-generated]\nThe reportkit package coordinates storage and summary through explicit relative imports. build_report overwrites sample input, uses randomness and time, and writes a report. Successful clock-dependent behavior is quarantined, so the source description is not a verified success claim.\n\nObserved return types: \nObserved exceptions: \nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'

import random
import time

from .storage import read_numbers, write_report
from .summary import summarize


def build_report(input_path, output_path, seed=None):
    u'[Machine-generated]\nCreate or overwrite the input file with fixed numeric sample data, read it, compute a summary, add a pseudo-random ticket and current timestamp, then write and return the report. This describes source structure: successful training outcomes are unavailable because clock-dependent cases were quarantined. Suspected legacy bug: the supplied input path is overwritten before being read.\n\nObserved return types: \nObserved exceptions: exceptions.TypeError\nLimitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.'
    with open(input_path, 'wb') as stream:
        stream.write('7\n-2\n0\n')
    numbers = read_numbers(input_path)
    report = summarize(numbers)
    report['ticket'] = random.Random(seed).randint(100, 999)
    report['created_at'] = time.time()
    write_report(output_path, report)
    return report
