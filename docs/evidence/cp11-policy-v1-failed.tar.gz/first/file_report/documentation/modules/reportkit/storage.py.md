[Machine-generated]
Storage helpers read binary numeric files and write sorted report lines. Both operate on supplied paths; errors propagate. Python 2 byte formatting and mapping iteration are migration hazards.

Observed return types: 
Observed exceptions: 
Limitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.
