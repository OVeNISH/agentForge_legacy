[Machine-generated]
A pure summary helper computes count and an integer-rounded mean, with an explicit empty-input result. No project-local dependencies are imported.

Observed return types: 
Observed exceptions: 
Limitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.
