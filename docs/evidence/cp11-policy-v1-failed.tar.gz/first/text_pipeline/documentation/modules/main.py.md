[Machine-generated]
Text helpers strip/filter names, attach positions, encode and decode UTF-8, and describe lengths and types. describe calls decode_label. The main block prints examples using Python 2 print syntax.

Observed return types: 
Observed exceptions: 
Limitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.
