[Machine-generated]
The ledger is one module with three independent helpers and a demonstration main block. There are no project-local import dependencies. Rounding and error behavior follow the original Python 2 implementation.

Observed return types: 
Observed exceptions: 
Limitations: Source-based description. Claims cover training observations only; untested inputs, dynamic calls and quarantined behavior are not proven.
